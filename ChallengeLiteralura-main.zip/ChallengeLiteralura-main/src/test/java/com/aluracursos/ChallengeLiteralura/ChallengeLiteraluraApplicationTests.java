package com.aluracursos.ChallengeLiteralura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeLiteraluraApplicationTests {

	@Test
	void contextLoads() {
	}

}
